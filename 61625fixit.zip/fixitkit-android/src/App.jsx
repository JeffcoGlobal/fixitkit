import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { 
  CreditCard, 
  FileText, 
  MessageCircle, 
  BarChart3, 
  BookOpen, 
  CheckCircle, 
  AlertCircle,
  Globe,
  Shield,
  Star,
  TrendingUp,
  Download,
  Play,
  Settings,
  Info,
  Lock,
  Smartphone,
  Users,
  Award,
  Clock,
  Target,
  Zap,
  Brain,
  GraduationCap,
  FileCheck,
  Calculator,
  HelpCircle,
  ChevronRight,
  Menu,
  X,
  Wifi,
  WifiOff
} from 'lucide-react'
import { LetterGenerator } from './components/LetterGenerator.jsx'
import { AIAssistant } from './components/AIAssistant.jsx'
import './App.css'
import './mobile.css'

function App() {
  const [language, setLanguage] = useState('en')
  const [creditScore, setCreditScore] = useState(650)
  const [progress, setProgress] = useState(35)
  const [activeTab, setActiveTab] = useState('dashboard')
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [isOnline, setIsOnline] = useState(navigator.onLine)
  const [installPrompt, setInstallPrompt] = useState(null)
  const [isStandalone, setIsStandalone] = useState(false)
  const [userProfile, setUserProfile] = useState({
    name: '',
    registrationCode: '',
    subscriptionTier: 'basic',
    daysActive: 28,
    completedModules: 2,
    totalModules: 8
  })

  // Check if app is running as PWA
  useEffect(() => {
    setIsStandalone(window.matchMedia('(display-mode: standalone)').matches)
  }, [])

  // Handle online/offline status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)
    
    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)
    
    return () => {
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  // Handle PWA install prompt
  useEffect(() => {
    const handleBeforeInstallPrompt = (e) => {
      e.preventDefault()
      setInstallPrompt(e)
    }
    
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt)
    }
  }, [])

  // Handle tab changes from URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const tab = urlParams.get('tab')
    if (tab && ['dashboard', 'education', 'letters', 'ai', 'tools'].includes(tab)) {
      setActiveTab(tab)
    }
  }, [])

  // Update URL when tab changes
  useEffect(() => {
    const url = new URL(window.location)
    url.searchParams.set('tab', activeTab)
    window.history.replaceState({}, '', url)
  }, [activeTab])

  // Close mobile menu when tab changes
  useEffect(() => {
    setMobileMenuOpen(false)
  }, [activeTab])

  const translations = {
    en: {
      title: "FixItKit™",
      subtitle: "Smart Credit Education",
      tagline: "Take control of your credit — no agents, no pressure, no risk.",
      poweredBy: "Powered by JEFFCO Global Solutions",
      dashboard: "Dashboard",
      education: "Education",
      letters: "Letters",
      progress: "Progress",
      aiAssistant: "AI Assistant",
      tools: "Tools",
      settings: "Settings",
      creditScore: "Credit Score",
      improvement: "Improvement Potential",
      nextSteps: "Next Steps",
      getStarted: "Get Started",
      learnMore: "Learn More",
      generateLetter: "Generate Letter",
      askAI: "Ask AI Assistant",
      modules: "Learning Modules",
      templates: "Letter Templates",
      tracking: "Progress Tracking",
      compliance: "100% Compliant",
      bilingual: "Bilingual Support",
      aiPowered: "AI-Powered",
      educational: "Educational Only",
      noServices: "No Credit Services",
      disclaimer: "For educational purposes only. We do not offer credit repair services.",
      welcome: "Welcome to FixItKit™",
      welcomeMsg: "Your complete credit education toolkit",
      currentScore: "Current Score",
      targetScore: "Target Score",
      daysActive: "Days Active",
      completedModules: "Completed Modules",
      subscriptionTier: "Subscription Tier",
      registrationCode: "Registration Code",
      upgradeNow: "Upgrade Now",
      features: "Features",
      creditEducation: "Credit Education",
      disputeLetters: "Dispute Letters",
      aiGuidance: "AI Guidance",
      progressTracking: "Progress Tracking",
      bilingualSupport: "Bilingual Support",
      mobileOptimized: "Mobile Optimized",
      secureCompliant: "Secure & Compliant",
      noResultsPromised: "No Results Promised",
      educationalPurpose: "Educational Purpose Only",
      selfHelp: "Self-Help Approach",
      legalCompliance: "Legal Compliance",
      fcraRights: "FCRA Rights",
      creditReportBasics: "Credit Report Basics",
      disputeProcess: "Dispute Process",
      buildingCredit: "Building Credit",
      creditUtilization: "Credit Utilization",
      paymentHistory: "Payment History",
      creditMix: "Credit Mix",
      newCredit: "New Credit",
      quickStart: "Quick Start Guide",
      videoTutorials: "Video Tutorials",
      templates: "Templates",
      calculator: "Calculator",
      tracker: "Tracker",
      resources: "Resources",
      support: "Support",
      about: "About",
      privacy: "Privacy",
      terms: "Terms",
      contact: "Contact",
      menu: "Menu",
      offline: "You're offline",
      offlineMessage: "Some features may be limited while offline",
      installApp: "Install App",
      installMessage: "Install FixItKit™ for quick access"
    },
    es: {
      title: "FixItKit™",
      subtitle: "Educación Inteligente de Crédito",
      tagline: "Toma control de tu crédito — sin agentes, sin presión, sin riesgo.",
      poweredBy: "Impulsado por JEFFCO Global Solutions",
      dashboard: "Panel",
      education: "Educación",
      letters: "Cartas",
      progress: "Progreso",
      aiAssistant: "Asistente IA",
      tools: "Herramientas",
      settings: "Configuración",
      creditScore: "Puntaje de Crédito",
      improvement: "Potencial de Mejora",
      nextSteps: "Próximos Pasos",
      getStarted: "Comenzar",
      learnMore: "Aprender Más",
      generateLetter: "Generar Carta",
      askAI: "Preguntar a IA",
      modules: "Módulos de Aprendizaje",
      templates: "Plantillas de Cartas",
      tracking: "Seguimiento de Progreso",
      compliance: "100% Conforme",
      bilingual: "Soporte Bilingüe",
      aiPowered: "Impulsado por IA",
      educational: "Solo Educativo",
      noServices: "Sin Servicios de Crédito",
      disclaimer: "Solo para fines educativos. No ofrecemos servicios de reparación de crédito.",
      welcome: "Bienvenido a FixItKit™",
      welcomeMsg: "Tu kit completo de educación crediticia",
      currentScore: "Puntaje Actual",
      targetScore: "Puntaje Objetivo",
      daysActive: "Días Activo",
      completedModules: "Módulos Completados",
      subscriptionTier: "Nivel de Suscripción",
      registrationCode: "Código de Registro",
      upgradeNow: "Actualizar Ahora",
      features: "Características",
      creditEducation: "Educación Crediticia",
      disputeLetters: "Cartas de Disputa",
      aiGuidance: "Orientación IA",
      progressTracking: "Seguimiento de Progreso",
      bilingualSupport: "Soporte Bilingüe",
      mobileOptimized: "Optimizado para Móvil",
      secureCompliant: "Seguro y Conforme",
      noResultsPromised: "Sin Promesas de Resultados",
      educationalPurpose: "Solo Propósito Educativo",
      selfHelp: "Enfoque de Autoayuda",
      legalCompliance: "Cumplimiento Legal",
      fcraRights: "Derechos FCRA",
      creditReportBasics: "Conceptos Básicos del Reporte Crediticio",
      disputeProcess: "Proceso de Disputa",
      buildingCredit: "Construyendo Crédito",
      creditUtilization: "Utilización de Crédito",
      paymentHistory: "Historial de Pagos",
      creditMix: "Mezcla de Crédito",
      newCredit: "Nuevo Crédito",
      quickStart: "Guía de Inicio Rápido",
      videoTutorials: "Tutoriales en Video",
      templates: "Plantillas",
      calculator: "Calculadora",
      tracker: "Rastreador",
      resources: "Recursos",
      support: "Soporte",
      about: "Acerca de",
      privacy: "Privacidad",
      terms: "Términos",
      contact: "Contacto",
      menu: "Menú",
      offline: "Estás desconectado",
      offlineMessage: "Algunas funciones pueden estar limitadas sin conexión",
      installApp: "Instalar App",
      installMessage: "Instala FixItKit™ para acceso rápido"
    }
  }

  const t = translations[language]

  const educationModules = [
    { 
      id: 1, 
      title: language === 'en' ? "Understanding Credit Reports" : "Entendiendo los Reportes de Crédito", 
      completed: true, 
      duration: "15 min",
      description: language === 'en' ? "Learn how to read and understand your credit report" : "Aprende a leer y entender tu reporte crediticio",
      icon: FileCheck
    },
    { 
      id: 2, 
      title: language === 'en' ? "FCRA Rights & Protections" : "Derechos y Protecciones FCRA", 
      completed: true, 
      duration: "20 min",
      description: language === 'en' ? "Know your rights under federal credit laws" : "Conoce tus derechos bajo las leyes federales de crédito",
      icon: Shield
    },
    { 
      id: 3, 
      title: language === 'en' ? "Dispute Process Fundamentals" : "Fundamentos del Proceso de Disputa", 
      completed: false, 
      duration: "25 min",
      description: language === 'en' ? "Master the art of disputing credit report errors" : "Domina el arte de disputar errores en el reporte crediticio",
      icon: AlertCircle
    },
    { 
      id: 4, 
      title: language === 'en' ? "Building Positive Credit History" : "Construyendo Historial Crediticio Positivo", 
      completed: false, 
      duration: "30 min",
      description: language === 'en' ? "Strategies for building and maintaining good credit" : "Estrategias para construir y mantener buen crédito",
      icon: TrendingUp
    },
    { 
      id: 5, 
      title: language === 'en' ? "Credit Utilization Strategies" : "Estrategias de Utilización de Crédito", 
      completed: false, 
      duration: "18 min",
      description: language === 'en' ? "Optimize your credit utilization for better scores" : "Optimiza tu utilización de crédito para mejores puntajes",
      icon: Calculator
    },
    { 
      id: 6, 
      title: language === 'en' ? "Payment History Optimization" : "Optimización del Historial de Pagos", 
      completed: false, 
      duration: "22 min",
      description: language === 'en' ? "Learn how payment history affects your score" : "Aprende cómo el historial de pagos afecta tu puntaje",
      icon: Clock
    },
    { 
      id: 7, 
      title: language === 'en' ? "Credit Mix and New Credit" : "Mezcla de Crédito y Nuevo Crédito", 
      completed: false, 
      duration: "20 min",
      description: language === 'en' ? "Understanding different types of credit accounts" : "Entendiendo diferentes tipos de cuentas de crédito",
      icon: Star
    },
    { 
      id: 8, 
      title: language === 'en' ? "Long-term Credit Management" : "Gestión de Crédito a Largo Plazo", 
      completed: false, 
      duration: "35 min",
      description: language === 'en' ? "Maintain excellent credit for life" : "Mantén excelente crédito de por vida",
      icon: Target
    }
  ]

  const letterTemplates = [
    { 
      id: 1, 
      type: language === 'en' ? "Dispute Letter" : "Carta de Disputa", 
      description: language === 'en' ? "Challenge inaccurate information" : "Desafía información inexacta", 
      icon: FileText,
      category: "dispute"
    },
    { 
      id: 2, 
      type: language === 'en' ? "Validation Letter" : "Carta de Validación", 
      description: language === 'en' ? "Request debt validation" : "Solicita validación de deuda", 
      icon: Shield,
      category: "validation"
    },
    { 
      id: 3, 
      type: language === 'en' ? "Goodwill Letter" : "Carta de Buena Voluntad", 
      description: language === 'en' ? "Request goodwill deletion" : "Solicita eliminación de buena voluntad", 
      icon: Star,
      category: "goodwill"
    },
    { 
      id: 4, 
      type: language === 'en' ? "Inquiry Removal" : "Eliminación de Consulta", 
      description: language === 'en' ? "Remove unauthorized inquiries" : "Elimina consultas no autorizadas", 
      icon: AlertCircle,
      category: "inquiry"
    }
  ]

  const features = [
    { icon: GraduationCap, title: t.creditEducation, description: language === 'en' ? "Comprehensive credit education modules" : "Módulos completos de educación crediticia" },
    { icon: FileText, title: t.disputeLetters, description: language === 'en' ? "Professional letter templates" : "Plantillas de cartas profesionales" },
    { icon: Brain, title: t.aiGuidance, description: language === 'en' ? "24/7 AI assistant support" : "Soporte de asistente IA 24/7" },
    { icon: BarChart3, title: t.progressTracking, description: language === 'en' ? "Track your credit journey" : "Rastrea tu viaje crediticio" },
    { icon: Globe, title: t.bilingualSupport, description: language === 'en' ? "English and Spanish support" : "Soporte en inglés y español" },
    { icon: Smartphone, title: t.mobileOptimized, description: language === 'en' ? "Works on all devices" : "Funciona en todos los dispositivos" }
  ]

  const complianceFeatures = [
    { icon: Shield, title: t.secureCompliant, description: language === 'en' ? "CROA compliant educational product" : "Producto educativo conforme a CROA" },
    { icon: AlertCircle, title: t.noResultsPromised, description: language === 'en' ? "No guarantees or promises made" : "Sin garantías o promesas" },
    { icon: BookOpen, title: t.educationalPurpose, description: language === 'en' ? "Educational content only" : "Solo contenido educativo" },
    { icon: Users, title: t.selfHelp, description: language === 'en' ? "Self-help approach" : "Enfoque de autoayuda" }
  ]

  const handleInstallApp = async () => {
    if (installPrompt) {
      installPrompt.prompt()
      const { outcome } = await installPrompt.userChoice
      console.log(`User response to install prompt: ${outcome}`)
      setInstallPrompt(null)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      {/* Offline Banner */}
      {!isOnline && (
        <div className="bg-red-50 dark:bg-red-900/20 border-b border-red-200 dark:border-red-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
            <div className="flex items-center justify-center space-x-2 text-sm text-red-800 dark:text-red-200">
              <WifiOff className="w-4 h-4" />
              <span>{t.offline} - {t.offlineMessage}</span>
            </div>
          </div>
        </div>
      )}

      {/* Install App Banner */}
      {installPrompt && !isStandalone && (
        <div className="bg-amber-50 dark:bg-amber-900/20 border-b border-amber-200 dark:border-amber-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
            <div className="flex items-center justify-between text-sm text-amber-800 dark:text-amber-200">
              <div className="flex items-center space-x-2">
                <Smartphone className="w-4 h-4" />
                <span>{t.installMessage}</span>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={handleInstallApp}
                className="text-amber-800 border-amber-300 hover:bg-amber-100"
              >
                {t.installApp}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="bg-white dark:bg-slate-800 shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-amber-400 to-amber-600 rounded-lg flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-900 dark:text-white">{t.title}</h1>
                <p className="text-xs text-slate-600 dark:text-slate-300">{t.poweredBy}</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-4">
              {isOnline && (
                <div className="flex items-center space-x-1 text-green-600 dark:text-green-400">
                  <Wifi className="w-4 h-4" />
                  <span className="text-xs">Online</span>
                </div>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLanguage(language === 'en' ? 'es' : 'en')}
                className="flex items-center space-x-2"
              >
                <Globe className="w-4 h-4" />
                <span>{language === 'en' ? 'ES' : 'EN'}</span>
              </Button>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white dark:bg-slate-800 border-t">
            <div className="px-4 py-2 space-y-2">
              {isOnline && (
                <div className="flex items-center justify-center space-x-1 text-green-600 dark:text-green-400 py-2">
                  <Wifi className="w-4 h-4" />
                  <span className="text-sm">Online</span>
                </div>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLanguage(language === 'en' ? 'es' : 'en')}
                className="w-full flex items-center justify-center space-x-2"
              >
                <Globe className="w-4 h-4" />
                <span>{language === 'en' ? 'Español' : 'English'}</span>
              </Button>
            </div>
          </div>
        )}
      </header>

      {/* Legal Disclaimer Banner */}
      <div className="bg-amber-50 dark:bg-amber-900/20 border-b border-amber-200 dark:border-amber-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-2">
          <div className="flex items-center justify-center space-x-2 text-sm text-amber-800 dark:text-amber-200">
            <Info className="w-4 h-4 flex-shrink-0" />
            <span className="text-center">
              {t.disclaimer}
            </span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 mb-8 touch-feedback">
            <TabsTrigger value="dashboard" className="flex items-center space-x-2">
              <BarChart3 className="w-4 h-4" />
              <span className="hidden sm:inline">{t.dashboard}</span>
            </TabsTrigger>
            <TabsTrigger value="education" className="flex items-center space-x-2">
              <BookOpen className="w-4 h-4" />
              <span className="hidden sm:inline">{t.education}</span>
            </TabsTrigger>
            <TabsTrigger value="letters" className="flex items-center space-x-2">
              <FileText className="w-4 h-4" />
              <span className="hidden sm:inline">{t.letters}</span>
            </TabsTrigger>
            <TabsTrigger value="ai" className="flex items-center space-x-2">
              <MessageCircle className="w-4 h-4" />
              <span className="hidden sm:inline">{t.aiAssistant}</span>
            </TabsTrigger>
            <TabsTrigger value="tools" className="flex items-center space-x-2">
              <Calculator className="w-4 h-4" />
              <span className="hidden sm:inline">{t.tools}</span>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-2">{t.welcome}</h2>
              <p className="text-lg text-slate-600 dark:text-slate-300">{t.welcomeMsg}</p>
              <p className="text-sm text-amber-600 dark:text-amber-400 mt-2">{t.tagline}</p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <Card className="touch-feedback">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                    {t.currentScore}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{creditScore}</div>
                  <div className="flex items-center mt-2">
                    <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                    <span className="text-sm text-green-500">+25 {language === 'en' ? 'this month' : 'este mes'}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="touch-feedback">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                    {t.targetScore}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">750</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                    {language === 'en' ? '100 points to go' : '100 puntos por alcanzar'}
                  </div>
                </CardContent>
              </Card>

              <Card className="touch-feedback">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                    {t.daysActive}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">{userProfile.daysActive}</div>
                  <div className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                    {language === 'en' ? 'Keep it up!' : '¡Sigue así!'}
                  </div>
                </CardContent>
              </Card>

              <Card className="touch-feedback">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-slate-600 dark:text-slate-300">
                    {t.completedModules}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-slate-900 dark:text-white">
                    {userProfile.completedModules}/{userProfile.totalModules}
                  </div>
                  <div className="text-sm text-slate-500 dark:text-slate-400 mt-2">
                    {Math.round((userProfile.completedModules / userProfile.totalModules) * 100)}% {language === 'en' ? 'complete' : 'completo'}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Progress and Next Steps */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="w-5 h-5" />
                    <span>{t.progress}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>{language === 'en' ? 'Overall Progress' : 'Progreso General'}</span>
                        <span>{progress}%</span>
                      </div>
                      <Progress value={progress} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>{language === 'en' ? 'Education Modules' : 'Módulos Educativos'}</span>
                        <span>{Math.round((userProfile.completedModules / userProfile.totalModules) * 100)}%</span>
                      </div>
                      <Progress value={(userProfile.completedModules / userProfile.totalModules) * 100} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>{language === 'en' ? 'Action Items' : 'Elementos de Acción'}</span>
                        <span>60%</span>
                      </div>
                      <Progress value={60} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5" />
                    <span>{t.nextSteps}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-amber-400 rounded-full"></div>
                      <span className="text-sm">
                        {language === 'en' ? 'Complete Module 3: Dispute Process' : 'Completar Módulo 3: Proceso de Disputa'}
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-slate-300 rounded-full"></div>
                      <span className="text-sm">
                        {language === 'en' ? 'Generate your first dispute letter' : 'Generar tu primera carta de disputa'}
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-slate-300 rounded-full"></div>
                      <span className="text-sm">
                        {language === 'en' ? 'Review credit report updates' : 'Revisar actualizaciones del reporte crediticio'}
                      </span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-slate-300 rounded-full"></div>
                      <span className="text-sm">
                        {language === 'en' ? 'Set up credit monitoring' : 'Configurar monitoreo de crédito'}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Features Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="w-5 h-5" />
                  <span>{t.features}</span>
                </CardTitle>
                <CardDescription>
                  {language === 'en' ? 'Everything you need for credit education' : 'Todo lo que necesitas para educación crediticia'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {features.map((feature, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800 touch-feedback">
                      <feature.icon className="w-5 h-5 text-amber-600 dark:text-amber-400 mt-1" />
                      <div>
                        <h4 className="font-medium text-slate-900 dark:text-white">{feature.title}</h4>
                        <p className="text-sm text-slate-600 dark:text-slate-300">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Compliance Information */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="w-5 h-5" />
                  <span>{t.legalCompliance}</span>
                </CardTitle>
                <CardDescription>
                  {language === 'en' ? 'Educational product compliance information' : 'Información de cumplimiento del producto educativo'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {complianceFeatures.map((feature, index) => (
                    <div key={index} className="flex items-start space-x-3 p-3 rounded-lg bg-green-50 dark:bg-green-900/20 touch-feedback">
                      <feature.icon className="w-5 h-5 text-green-600 dark:text-green-400 mt-1" />
                      <div>
                        <h4 className="font-medium text-slate-900 dark:text-white">{feature.title}</h4>
                        <p className="text-sm text-slate-600 dark:text-slate-300">{feature.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <Alert className="mt-4">
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    {language === 'en' 
                      ? "FixItKit™ is an educational product designed to teach you about credit repair. We do not provide credit repair services or guarantee any specific results. All actions taken are your own responsibility."
                      : "FixItKit™ es un producto educativo diseñado para enseñarte sobre reparación de crédito. No proporcionamos servicios de reparación de crédito ni garantizamos resultados específicos. Todas las acciones tomadas son tu propia responsabilidad."
                    }
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Education Tab */}
          <TabsContent value="education" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">{t.modules}</h2>
              <p className="text-slate-600 dark:text-slate-300">
                {language === 'en' ? 'Learn at your own pace with our comprehensive modules' : 'Aprende a tu propio ritmo con nuestros módulos completos'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {educationModules.map((module) => (
                <Card key={module.id} className={`cursor-pointer transition-all hover:shadow-lg touch-feedback ${module.completed ? 'border-green-200 bg-green-50 dark:bg-green-900/20' : ''}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                          module.completed ? 'bg-green-100 dark:bg-green-900/20' : 'bg-amber-100 dark:bg-amber-900/20'
                        }`}>
                          {module.completed ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : (
                            <module.icon className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                          )}
                        </div>
                        <div>
                          <CardTitle className="text-lg">{module.title}</CardTitle>
                          <CardDescription>{module.duration}</CardDescription>
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-slate-600 dark:text-slate-300 mt-2">{module.description}</p>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      className="w-full touch-feedback" 
                      variant={module.completed ? "outline" : "default"}
                    >
                      {module.completed 
                        ? (language === 'en' ? "Review" : "Revisar")
                        : (language === 'en' ? "Start Module" : "Iniciar Módulo")
                      }
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Quick Start Guide */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Play className="w-5 h-5" />
                  <span>{t.quickStart}</span>
                </CardTitle>
                <CardDescription>
                  {language === 'en' ? 'Get started with your credit education journey' : 'Comienza tu viaje de educación crediticia'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800 touch-feedback">
                    <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900/20 rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-amber-600 dark:text-amber-400">1</span>
                    </div>
                    <div>
                      <h4 className="font-medium">
                        {language === 'en' ? 'Start with Credit Report Basics' : 'Comienza con Conceptos Básicos del Reporte Crediticio'}
                      </h4>
                      <p className="text-sm text-slate-600 dark:text-slate-300">
                        {language === 'en' ? 'Learn how to read and understand your credit report' : 'Aprende a leer y entender tu reporte crediticio'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800 touch-feedback">
                    <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900/20 rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-amber-600 dark:text-amber-400">2</span>
                    </div>
                    <div>
                      <h4 className="font-medium">
                        {language === 'en' ? 'Understand Your Rights' : 'Entiende Tus Derechos'}
                      </h4>
                      <p className="text-sm text-slate-600 dark:text-slate-300">
                        {language === 'en' ? 'Know your rights under FCRA and other credit laws' : 'Conoce tus derechos bajo FCRA y otras leyes de crédito'}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-800 touch-feedback">
                    <div className="w-8 h-8 bg-amber-100 dark:bg-amber-900/20 rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold text-amber-600 dark:text-amber-400">3</span>
                    </div>
                    <div>
                      <h4 className="font-medium">
                        {language === 'en' ? 'Practice with Letter Templates' : 'Practica con Plantillas de Cartas'}
                      </h4>
                      <p className="text-sm text-slate-600 dark:text-slate-300">
                        {language === 'en' ? 'Use our templates to create professional dispute letters' : 'Usa nuestras plantillas para crear cartas de disputa profesionales'}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Letters Tab */}
          <TabsContent value="letters" className="space-y-6">
            <LetterGenerator language={language} />
          </TabsContent>

          {/* AI Assistant Tab */}
          <TabsContent value="ai" className="space-y-6">
            <AIAssistant language={language} />
          </TabsContent>

          {/* Tools Tab */}
          <TabsContent value="tools" className="space-y-6">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">{t.tools}</h2>
              <p className="text-slate-600 dark:text-slate-300">
                {language === 'en' ? 'Helpful tools for your credit journey' : 'Herramientas útiles para tu viaje crediticio'}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="cursor-pointer transition-all hover:shadow-lg touch-feedback">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                      <Calculator className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <CardTitle>{language === 'en' ? 'Credit Utilization Calculator' : 'Calculadora de Utilización de Crédito'}</CardTitle>
                      <CardDescription>
                        {language === 'en' ? 'Calculate optimal credit utilization' : 'Calcula la utilización óptima de crédito'}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Button className="w-full touch-feedback">
                    {language === 'en' ? 'Open Calculator' : 'Abrir Calculadora'}
                  </Button>
                </CardContent>
              </Card>

              <Card className="cursor-pointer transition-all hover:shadow-lg touch-feedback">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-100 dark:bg-green-900/20 rounded-lg flex items-center justify-center">
                      <BarChart3 className="w-5 h-5 text-green-600 dark:text-green-400" />
                    </div>
                    <div>
                      <CardTitle>{language === 'en' ? 'Progress Tracker' : 'Rastreador de Progreso'}</CardTitle>
                      <CardDescription>
                        {language === 'en' ? 'Track your credit improvement' : 'Rastrea tu mejora crediticia'}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Button className="w-full touch-feedback">
                    {language === 'en' ? 'View Tracker' : 'Ver Rastreador'}
                  </Button>
                </CardContent>
              </Card>

              <Card className="cursor-pointer transition-all hover:shadow-lg touch-feedback">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/20 rounded-lg flex items-center justify-center">
                      <Clock className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                    </div>
                    <div>
                      <CardTitle>{language === 'en' ? 'Timeline Planner' : 'Planificador de Cronograma'}</CardTitle>
                      <CardDescription>
                        {language === 'en' ? 'Plan your credit repair timeline' : 'Planifica tu cronograma de reparación de crédito'}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Button className="w-full touch-feedback">
                    {language === 'en' ? 'Create Timeline' : 'Crear Cronograma'}
                  </Button>
                </CardContent>
              </Card>

              <Card className="cursor-pointer transition-all hover:shadow-lg touch-feedback">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-red-100 dark:bg-red-900/20 rounded-lg flex items-center justify-center">
                      <FileCheck className="w-5 h-5 text-red-600 dark:text-red-400" />
                    </div>
                    <div>
                      <CardTitle>{language === 'en' ? 'Document Organizer' : 'Organizador de Documentos'}</CardTitle>
                      <CardDescription>
                        {language === 'en' ? 'Organize your credit documents' : 'Organiza tus documentos de crédito'}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Button className="w-full touch-feedback">
                    {language === 'en' ? 'Organize Documents' : 'Organizar Documentos'}
                  </Button>
                </CardContent>
              </Card>

              <Card className="cursor-pointer transition-all hover:shadow-lg touch-feedback">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-orange-100 dark:bg-orange-900/20 rounded-lg flex items-center justify-center">
                      <Target className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                    </div>
                    <div>
                      <CardTitle>{language === 'en' ? 'Goal Setter' : 'Establecedor de Metas'}</CardTitle>
                      <CardDescription>
                        {language === 'en' ? 'Set and track credit goals' : 'Establece y rastrea metas de crédito'}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Button className="w-full touch-feedback">
                    {language === 'en' ? 'Set Goals' : 'Establecer Metas'}
                  </Button>
                </CardContent>
              </Card>

              <Card className="cursor-pointer transition-all hover:shadow-lg touch-feedback">
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-teal-100 dark:bg-teal-900/20 rounded-lg flex items-center justify-center">
                      <HelpCircle className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                    </div>
                    <div>
                      <CardTitle>{language === 'en' ? 'FAQ & Resources' : 'FAQ y Recursos'}</CardTitle>
                      <CardDescription>
                        {language === 'en' ? 'Common questions and resources' : 'Preguntas comunes y recursos'}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <Button className="w-full touch-feedback">
                    {language === 'en' ? 'View Resources' : 'Ver Recursos'}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="bg-white dark:bg-slate-800 border-t mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-amber-400 to-amber-600 rounded-lg flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-slate-900 dark:text-white">{t.title}</span>
              </div>
              <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">
                {t.poweredBy}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t.disclaimer}
              </p>
            </div>
            
            <div>
              <h4 className="font-medium text-slate-900 dark:text-white mb-4">{t.education}</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.fcraRights}</a></li>
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.creditReportBasics}</a></li>
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.disputeProcess}</a></li>
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.buildingCredit}</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-slate-900 dark:text-white mb-4">{t.tools}</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.templates}</a></li>
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.calculator}</a></li>
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.tracker}</a></li>
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.aiAssistant}</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-slate-900 dark:text-white mb-4">{t.support}</h4>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-300">
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.about}</a></li>
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.privacy}</a></li>
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.terms}</a></li>
                <li><a href="#" className="hover:text-amber-600 touch-feedback">{t.contact}</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-slate-200 dark:border-slate-700 mt-8 pt-8 text-center">
            <p className="text-sm text-slate-500 dark:text-slate-400">
              © 2024 JEFFCO Global Solutions. {language === 'en' ? 'All rights reserved.' : 'Todos los derechos reservados.'}
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-500 mt-2">
              {language === 'en' 
                ? 'FixItKit™ is an educational product. We do not provide credit repair services.'
                : 'FixItKit™ es un producto educativo. No proporcionamos servicios de reparación de crédito.'
              }
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

