import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Input } from '@/components/ui/input.jsx'
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User,
  Lightbulb,
  FileText,
  Calculator,
  HelpCircle
} from 'lucide-react'

export function AIAssistant({ language = 'en' }) {
  const [messages, setMessages] = useState([])
  const [inputMessage, setInputMessage] = useState('')
  const [isTyping, setIsTyping] = useState(false)

  const translations = {
    en: {
      title: "AI Credit Assistant",
      subtitle: "Get personalized guidance for your credit journey",
      placeholder: "Ask me anything about credit repair, dispute letters, or credit scores...",
      send: "Send",
      typing: "AI is typing...",
      quickActions: "Quick Actions",
      explainScore: "Explain my credit score",
      disputeHelp: "Help with disputes",
      letterAdvice: "Letter writing tips",
      timelineHelp: "Credit repair timeline"
    },
    es: {
      title: "Asistente de Crédito IA",
      subtitle: "Obtén orientación personalizada para tu viaje crediticio",
      placeholder: "Pregúntame cualquier cosa sobre reparación de crédito, cartas de disputa, o puntajes crediticios...",
      send: "Enviar",
      typing: "IA está escribiendo...",
      quickActions: "Acciones Rápidas",
      explainScore: "Explicar mi puntaje crediticio",
      disputeHelp: "Ayuda con disputas",
      letterAdvice: "Consejos para escribir cartas",
      timelineHelp: "Cronograma de reparación de crédito"
    }
  }

  const t = translations[language]

  const quickResponses = {
    en: {
      explainScore: "Your credit score is a 3-digit number (300-850) that represents your creditworthiness. Here's what the ranges mean:\n\n• 800-850: Excellent\n• 740-799: Very Good\n• 670-739: Good\n• 580-669: Fair\n• 300-579: Poor\n\nFactors affecting your score:\n• Payment history (35%)\n• Credit utilization (30%)\n• Length of credit history (15%)\n• Credit mix (10%)\n• New credit inquiries (10%)",
      
      disputeHelp: "Here's how to effectively dispute credit report errors:\n\n1. **Get your credit reports** from all 3 bureaus (free at annualcreditreport.com)\n\n2. **Identify errors** like:\n   • Wrong personal information\n   • Accounts that aren't yours\n   • Incorrect payment history\n   • Outdated negative information\n\n3. **Gather evidence** - bank statements, payment records, court documents\n\n4. **File disputes** with credit bureaus and creditors\n\n5. **Follow up** within 30-45 days\n\nRemember: This is for educational purposes only. You're learning to handle your own disputes.",
      
      letterAdvice: "Tips for effective dispute letters:\n\n**Keep it simple:**\n• State facts clearly\n• Include account numbers\n• Specify what's wrong\n• Request specific action\n\n**Be professional:**\n• Use formal business format\n• Keep emotions out\n• Stick to facts\n• Include supporting documents\n\n**Follow up:**\n• Send certified mail\n• Keep copies of everything\n• Track response times\n• Be persistent but patient\n\nUse our letter templates as starting points, but customize them for your specific situation.",
      
      timelineHelp: "Typical credit repair timeline:\n\n**Month 1-2:**\n• Get credit reports\n• Identify errors\n• Gather documentation\n• Send first round of disputes\n\n**Month 2-3:**\n• Follow up on disputes\n• Review bureau responses\n• Send additional disputes if needed\n\n**Month 3-6:**\n• Continue dispute process\n• Focus on payment history\n• Reduce credit utilization\n• Avoid new credit inquiries\n\n**Month 6-12:**\n• Monitor improvements\n• Maintain good habits\n• Consider secured cards if needed\n• Build positive credit history\n\nRemember: Credit repair takes time and patience. Focus on education and building good financial habits."
    },
    es: {
      explainScore: "Tu puntaje crediticio es un número de 3 dígitos (300-850) que representa tu solvencia crediticia. Esto es lo que significan los rangos:\n\n• 800-850: Excelente\n• 740-799: Muy Bueno\n• 670-739: Bueno\n• 580-669: Regular\n• 300-579: Pobre\n\nFactores que afectan tu puntaje:\n• Historial de pagos (35%)\n• Utilización de crédito (30%)\n• Duración del historial crediticio (15%)\n• Mezcla de crédito (10%)\n• Nuevas consultas de crédito (10%)",
      
      disputeHelp: "Aquí te explico cómo disputar errores en tu reporte crediticio efectivamente:\n\n1. **Obtén tus reportes crediticios** de las 3 agencias (gratis en annualcreditreport.com)\n\n2. **Identifica errores** como:\n   • Información personal incorrecta\n   • Cuentas que no son tuyas\n   • Historial de pagos incorrecto\n   • Información negativa desactualizada\n\n3. **Reúne evidencia** - estados bancarios, registros de pagos, documentos judiciales\n\n4. **Presenta disputas** con las agencias crediticias y acreedores\n\n5. **Haz seguimiento** dentro de 30-45 días\n\nRecuerda: Esto es solo para fines educativos. Estás aprendiendo a manejar tus propias disputas.",
      
      letterAdvice: "Consejos para cartas de disputa efectivas:\n\n**Manténlo simple:**\n• Declara los hechos claramente\n• Incluye números de cuenta\n• Especifica qué está mal\n• Solicita acción específica\n\n**Sé profesional:**\n• Usa formato comercial formal\n• Mantén las emociones fuera\n• Apégate a los hechos\n• Incluye documentos de apoyo\n\n**Haz seguimiento:**\n• Envía por correo certificado\n• Guarda copias de todo\n• Rastrea tiempos de respuesta\n• Sé persistente pero paciente\n\nUsa nuestras plantillas de cartas como puntos de partida, pero personalízalas para tu situación específica.",
      
      timelineHelp: "Cronograma típico de reparación de crédito:\n\n**Mes 1-2:**\n• Obtener reportes crediticios\n• Identificar errores\n• Reunir documentación\n• Enviar primera ronda de disputas\n\n**Mes 2-3:**\n• Seguimiento de disputas\n• Revisar respuestas de agencias\n• Enviar disputas adicionales si es necesario\n\n**Mes 3-6:**\n• Continuar proceso de disputas\n• Enfocarse en historial de pagos\n• Reducir utilización de crédito\n• Evitar nuevas consultas de crédito\n\n**Mes 6-12:**\n• Monitorear mejoras\n• Mantener buenos hábitos\n• Considerar tarjetas aseguradas si es necesario\n• Construir historial crediticio positivo\n\nRecuerda: La reparación de crédito toma tiempo y paciencia. Enfócate en la educación y en construir buenos hábitos financieros."
    }
  }

  const sendMessage = async (message = inputMessage) => {
    if (!message.trim()) return

    const userMessage = { type: 'user', content: message, timestamp: new Date() }
    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setIsTyping(true)

    // Simulate AI response delay
    setTimeout(() => {
      let response = "I'm here to help you learn about credit repair! Here are some things I can help you with:\n\n• Understanding credit scores and reports\n• Guidance on dispute processes\n• Letter writing tips and templates\n• Credit repair timelines and expectations\n• Educational resources and best practices\n\nRemember, this is for educational purposes only. I'm here to teach you how to handle your own credit repair journey.\n\nWhat specific topic would you like to learn about?"

      // Check for specific topics
      const lowerMessage = message.toLowerCase()
      if (lowerMessage.includes('score') || lowerMessage.includes('puntaje')) {
        response = quickResponses[language].explainScore
      } else if (lowerMessage.includes('dispute') || lowerMessage.includes('disputa')) {
        response = quickResponses[language].disputeHelp
      } else if (lowerMessage.includes('letter') || lowerMessage.includes('carta')) {
        response = quickResponses[language].letterAdvice
      } else if (lowerMessage.includes('timeline') || lowerMessage.includes('tiempo') || lowerMessage.includes('cronograma')) {
        response = quickResponses[language].timelineHelp
      } else if (lowerMessage.includes('utilization') || lowerMessage.includes('utilización')) {
        response = language === 'en' 
          ? "Credit utilization is the percentage of your available credit that you're using. Here's what you need to know:\n\n• Keep total utilization below 30%\n• Ideally, stay under 10% for best scores\n• Pay down balances before statement dates\n• Consider multiple payments per month\n• Don't close old cards (reduces available credit)\n\nExample: If you have $10,000 total credit limit, keep balances under $3,000 (preferably under $1,000)."
          : "La utilización de crédito es el porcentaje de tu crédito disponible que estás usando. Esto es lo que necesitas saber:\n\n• Mantén la utilización total por debajo del 30%\n• Idealmente, mantente por debajo del 10% para mejores puntajes\n• Paga saldos antes de las fechas de estado de cuenta\n• Considera múltiples pagos por mes\n• No cierres tarjetas viejas (reduce crédito disponible)\n\nEjemplo: Si tienes $10,000 de límite total de crédito, mantén saldos por debajo de $3,000 (preferiblemente por debajo de $1,000)."
      }

      const aiMessage = { type: 'ai', content: response, timestamp: new Date() }
      setMessages(prev => [...prev, aiMessage])
      setIsTyping(false)
    }, 1500)
  }

  const quickActions = [
    { key: 'explainScore', icon: Calculator, text: t.explainScore },
    { key: 'disputeHelp', icon: FileText, text: t.disputeHelp },
    { key: 'letterAdvice', icon: Lightbulb, text: t.letterAdvice },
    { key: 'timelineHelp', icon: HelpCircle, text: t.timelineHelp }
  ]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Bot className="w-5 h-5 text-blue-500" />
            <span>{t.title}</span>
          </CardTitle>
          <CardDescription>{t.subtitle}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Quick Actions */}
            <div>
              <h4 className="text-sm font-medium mb-2">{t.quickActions}</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {quickActions.map((action) => (
                  <Button
                    key={action.key}
                    variant="outline"
                    size="sm"
                    onClick={() => sendMessage(action.text)}
                    className="justify-start text-left h-auto p-3"
                  >
                    <action.icon className="w-4 h-4 mr-2 flex-shrink-0" />
                    <span className="text-xs">{action.text}</span>
                  </Button>
                ))}
              </div>
            </div>

            {/* Chat Messages */}
            <div className="border rounded-lg p-4 h-96 overflow-y-auto space-y-4 bg-gray-50">
              {messages.length === 0 && (
                <div className="text-center text-gray-500 mt-8">
                  <Bot className="w-12 h-12 mx-auto mb-2 text-blue-500" />
                  <p className="text-sm">
                    {language === 'en' 
                      ? "Hi! I'm your AI Credit Assistant. Ask me anything about credit repair!"
                      : "¡Hola! Soy tu Asistente de Crédito IA. ¡Pregúntame cualquier cosa sobre reparación de crédito!"
                    }
                  </p>
                </div>
              )}
              
              {messages.map((message, index) => (
                <div
                  key={index}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.type === 'user'
                        ? 'bg-blue-500 text-white'
                        : 'bg-white border'
                    }`}
                  >
                    <div className="flex items-start space-x-2">
                      {message.type === 'ai' && <Bot className="w-4 h-4 mt-1 text-blue-500" />}
                      {message.type === 'user' && <User className="w-4 h-4 mt-1" />}
                      <div className="flex-1">
                        <p className="text-sm whitespace-pre-line">{message.content}</p>
                        <p className={`text-xs mt-1 ${
                          message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                        }`}>
                          {message.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-white border p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Bot className="w-4 h-4 text-blue-500" />
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                      </div>
                      <span className="text-xs text-gray-500">{t.typing}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Input */}
            <div className="flex space-x-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                placeholder={t.placeholder}
                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                className="flex-1"
              />
              <Button onClick={() => sendMessage()} disabled={!inputMessage.trim() || isTyping}>
                <Send className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default AIAssistant

