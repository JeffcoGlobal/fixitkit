import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { 
  FileText, 
  Download, 
  Copy, 
  CheckCircle, 
  AlertCircle,
  Shield,
  Star,
  MessageCircle
} from 'lucide-react'

export function LetterGenerator({ language = 'en' }) {
  const [selectedTemplate, setSelectedTemplate] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    address: '',
    city: '',
    state: '',
    zip: '',
    creditorName: '',
    accountNumber: '',
    disputeReason: '',
    customText: ''
  })
  const [generatedLetter, setGeneratedLetter] = useState('')

  const translations = {
    en: {
      selectTemplate: "Select Letter Template",
      disputeLetter: "Dispute Letter",
      validationLetter: "Validation Letter", 
      goodwillLetter: "Goodwill Letter",
      inquiryRemoval: "Inquiry Removal Letter",
      personalInfo: "Personal Information",
      name: "Full Name",
      address: "Address",
      city: "City",
      state: "State",
      zip: "ZIP Code",
      accountDetails: "Account Details",
      creditorName: "Creditor Name",
      accountNumber: "Account Number",
      disputeReason: "Dispute Reason",
      customText: "Additional Information",
      generateLetter: "Generate Letter",
      downloadLetter: "Download Letter",
      copyLetter: "Copy to Clipboard",
      letterGenerated: "Letter Generated Successfully!",
      disclaimer: "This letter is for educational purposes only. Review and customize before sending."
    },
    es: {
      selectTemplate: "Seleccionar Plantilla de Carta",
      disputeLetter: "Carta de Disputa",
      validationLetter: "Carta de Validación",
      goodwillLetter: "Carta de Buena Voluntad", 
      inquiryRemoval: "Carta de Eliminación de Consulta",
      personalInfo: "Información Personal",
      name: "Nombre Completo",
      address: "Dirección",
      city: "Ciudad",
      state: "Estado",
      zip: "Código Postal",
      accountDetails: "Detalles de la Cuenta",
      creditorName: "Nombre del Acreedor",
      accountNumber: "Número de Cuenta",
      disputeReason: "Razón de la Disputa",
      customText: "Información Adicional",
      generateLetter: "Generar Carta",
      downloadLetter: "Descargar Carta",
      copyLetter: "Copiar al Portapapeles",
      letterGenerated: "¡Carta Generada Exitosamente!",
      disclaimer: "Esta carta es solo para fines educativos. Revise y personalice antes de enviar."
    }
  }

  const t = translations[language]

  const letterTemplates = {
    dispute: {
      en: `[Date]

[Your Name]
[Your Address]
[City, State ZIP Code]

[Creditor Name]
[Creditor Address]

Re: Account Number: [Account Number]

Dear Sir/Madam,

I am writing to dispute the following information in my file. The items I dispute are also encircled on the attached copy of the report I received.

This item is (inaccurate or incomplete or outdated) because [Dispute Reason].

I am requesting that the item be removed (or request another specific change) to correct the information.

Enclosed are copies of (use this sentence if applicable and describe any enclosed documentation, such as payment records, court documents) supporting my position. Please reinvestigate this (these) matter(s) and (delete or correct) the disputed item(s) as soon as possible.

[Additional Information]

Sincerely,
[Your Name]

Enclosures: (List what you are enclosing)`,
      es: `[Fecha]

[Su Nombre]
[Su Dirección]
[Ciudad, Estado Código Postal]

[Nombre del Acreedor]
[Dirección del Acreedor]

Re: Número de Cuenta: [Número de Cuenta]

Estimado Señor/Señora,

Le escribo para disputar la siguiente información en mi archivo. Los elementos que disputo también están marcados en la copia adjunta del informe que recibí.

Este elemento es (inexacto o incompleto o desactualizado) porque [Razón de la Disputa].

Solicito que el elemento sea eliminado (o solicite otro cambio específico) para corregir la información.

Se adjuntan copias de (use esta oración si es aplicable y describa cualquier documentación adjunta, como registros de pago, documentos judiciales) que respaldan mi posición. Por favor reinvestigue este(estos) asunto(s) y (elimine o corrija) el(los) elemento(s) disputado(s) lo antes posible.

[Información Adicional]

Atentamente,
[Su Nombre]

Adjuntos: (Liste lo que está adjuntando)`
    },
    validation: {
      en: `[Date]

[Your Name]
[Your Address]
[City, State ZIP Code]

[Creditor Name]
[Creditor Address]

Re: Account Number: [Account Number]

Dear Sir/Madam,

This letter is sent in response to a notice I received from you on [Date]. Be advised that this is not a refusal to pay, but a notice sent pursuant to the Fair Debt Collection Practices Act, 15 USC 1692g Sec. 809 (b) that your claim is disputed and validation is requested.

This is NOT a refusal to pay, but a notice that your claim is disputed. Under the law, you must verify the debt. Please provide me with the following information:

1. What the money you say I owe is for;
2. Explain and show me how you calculated what you say I owe;
3. Provide me with copies of any papers that show I agreed to pay what you say I owe;
4. Prove the Statute of Limitations has not expired on this account;
5. Show me that you are licensed to collect in my state;
6. Provide documentation that you own this debt.

If you cannot provide this information, then you must stop collection of this debt, and you cannot report it to credit reporting agencies.

If you fail to respond to this validation notice, I will file complaints with the Consumer Financial Protection Bureau, my State Attorney General's office, and the Federal Trade Commission.

[Additional Information]

Sincerely,
[Your Name]`,
      es: `[Fecha]

[Su Nombre]
[Su Dirección]
[Ciudad, Estado Código Postal]

[Nombre del Acreedor]
[Dirección del Acreedor]

Re: Número de Cuenta: [Número de Cuenta]

Estimado Señor/Señora,

Esta carta se envía en respuesta a un aviso que recibí de usted el [Fecha]. Tenga en cuenta que esto no es una negativa a pagar, sino un aviso enviado de conformidad con la Ley de Prácticas Justas de Cobro de Deudas, 15 USC 1692g Sec. 809 (b) que su reclamo está disputado y se solicita validación.

Esto NO es una negativa a pagar, sino un aviso de que su reclamo está disputado. Bajo la ley, usted debe verificar la deuda. Por favor proporcione la siguiente información:

1. Para qué es el dinero que dice que debo;
2. Explique y muéstreme cómo calculó lo que dice que debo;
3. Proporcione copias de cualquier documento que muestre que acordé pagar lo que dice que debo;
4. Pruebe que el Estatuto de Limitaciones no ha expirado en esta cuenta;
5. Muéstreme que tiene licencia para cobrar en mi estado;
6. Proporcione documentación de que usted posee esta deuda.

Si no puede proporcionar esta información, entonces debe detener el cobro de esta deuda, y no puede reportarla a las agencias de informes crediticios.

Si no responde a este aviso de validación, presentaré quejas ante la Oficina de Protección Financiera del Consumidor, la oficina del Fiscal General de mi Estado, y la Comisión Federal de Comercio.

[Información Adicional]

Atentamente,
[Su Nombre]`
    },
    goodwill: {
      en: `[Date]

[Your Name]
[Your Address]
[City, State ZIP Code]

[Creditor Name]
[Creditor Address]

Re: Account Number: [Account Number]

Dear Sir/Madam,

I am writing to request a goodwill adjustment to my credit report regarding the above-referenced account.

I acknowledge that I was late on this account, and I take full responsibility for this oversight. However, I have been a loyal customer for [time period] and have maintained a good payment history overall.

The late payment was due to [brief explanation - job loss, medical emergency, etc.]. Since then, I have taken steps to ensure this situation does not happen again, including [specific steps taken].

I am respectfully requesting that you consider removing this negative mark from my credit report as a gesture of goodwill. I value our relationship and would appreciate your consideration of this request.

I have attached documentation showing my improved financial situation and commitment to maintaining good credit.

[Additional Information]

Thank you for your time and consideration.

Sincerely,
[Your Name]

Enclosures: (List supporting documents)`,
      es: `[Fecha]

[Su Nombre]
[Su Dirección]
[Ciudad, Estado Código Postal]

[Nombre del Acreedor]
[Dirección del Acreedor]

Re: Número de Cuenta: [Número de Cuenta]

Estimado Señor/Señora,

Le escribo para solicitar un ajuste de buena voluntad a mi informe crediticio con respecto a la cuenta mencionada anteriormente.

Reconozco que llegué tarde en esta cuenta, y asumo la responsabilidad total por este descuido. Sin embargo, he sido un cliente leal durante [período de tiempo] y he mantenido un buen historial de pagos en general.

El pago tardío se debió a [breve explicación - pérdida de trabajo, emergencia médica, etc.]. Desde entonces, he tomado medidas para asegurar que esta situación no vuelva a ocurrir, incluyendo [pasos específicos tomados].

Respetuosamente solicito que considere eliminar esta marca negativa de mi informe crediticio como un gesto de buena voluntad. Valoro nuestra relación y agradecería su consideración de esta solicitud.

He adjuntado documentación que muestra mi situación financiera mejorada y compromiso de mantener buen crédito.

[Información Adicional]

Gracias por su tiempo y consideración.

Atentamente,
[Su Nombre]

Adjuntos: (Liste documentos de apoyo)`
    },
    inquiry: {
      en: `[Date]

[Your Name]
[Your Address]
[City, State ZIP Code]

[Credit Bureau Name]
[Credit Bureau Address]

Re: Unauthorized Credit Inquiry Removal Request

Dear Sir/Madam,

I am writing to dispute an unauthorized inquiry on my credit report. According to the Fair Credit Reporting Act (FCRA), I have the right to dispute any inaccurate or unauthorized information on my credit report.

The inquiry I am disputing is:
- Creditor: [Creditor Name]
- Date of Inquiry: [Date]
- Type: [Hard/Soft Inquiry]

I did not authorize this inquiry, and I have no knowledge of any application or request for credit with this company. This inquiry is negatively affecting my credit score and should be removed immediately.

Please investigate this matter and remove this unauthorized inquiry from my credit report within 30 days as required by law.

[Additional Information]

I have enclosed a copy of my identification and proof of address for verification purposes.

Sincerely,
[Your Name]

Enclosures: Copy of ID, Proof of Address`,
      es: `[Fecha]

[Su Nombre]
[Su Dirección]
[Ciudad, Estado Código Postal]

[Nombre de la Oficina de Crédito]
[Dirección de la Oficina de Crédito]

Re: Solicitud de Eliminación de Consulta de Crédito No Autorizada

Estimado Señor/Señora,

Le escribo para disputar una consulta no autorizada en mi informe crediticio. Según la Ley de Informes de Crédito Justos (FCRA), tengo el derecho de disputar cualquier información inexacta o no autorizada en mi informe crediticio.

La consulta que estoy disputando es:
- Acreedor: [Nombre del Acreedor]
- Fecha de la Consulta: [Fecha]
- Tipo: [Consulta Dura/Suave]

No autoricé esta consulta, y no tengo conocimiento de ninguna aplicación o solicitud de crédito con esta compañía. Esta consulta está afectando negativamente mi puntaje crediticio y debe ser eliminada inmediatamente.

Por favor investigue este asunto y elimine esta consulta no autorizada de mi informe crediticio dentro de 30 días como lo requiere la ley.

[Información Adicional]

He adjuntado una copia de mi identificación y prueba de dirección para propósitos de verificación.

Atentamente,
[Su Nombre]

Adjuntos: Copia de ID, Prueba de Dirección`
    }
  }

  const generateLetter = () => {
    if (!selectedTemplate) return

    let template = letterTemplates[selectedTemplate][language]
    
    // Replace placeholders with form data
    template = template
      .replace(/\[Your Name\]/g, formData.name || '[Your Name]')
      .replace(/\[Su Nombre\]/g, formData.name || '[Su Nombre]')
      .replace(/\[Your Address\]/g, formData.address || '[Your Address]')
      .replace(/\[Su Dirección\]/g, formData.address || '[Su Dirección]')
      .replace(/\[City, State ZIP Code\]/g, 
        `${formData.city || '[City]'}, ${formData.state || '[State]'} ${formData.zip || '[ZIP]'}`)
      .replace(/\[Ciudad, Estado Código Postal\]/g,
        `${formData.city || '[Ciudad]'}, ${formData.state || '[Estado]'} ${formData.zip || '[Código Postal]'}`)
      .replace(/\[Creditor Name\]/g, formData.creditorName || '[Creditor Name]')
      .replace(/\[Nombre del Acreedor\]/g, formData.creditorName || '[Nombre del Acreedor]')
      .replace(/\[Account Number\]/g, formData.accountNumber || '[Account Number]')
      .replace(/\[Número de Cuenta\]/g, formData.accountNumber || '[Número de Cuenta]')
      .replace(/\[Dispute Reason\]/g, formData.disputeReason || '[Dispute Reason]')
      .replace(/\[Razón de la Disputa\]/g, formData.disputeReason || '[Razón de la Disputa]')
      .replace(/\[Additional Information\]/g, formData.customText || '[Additional Information]')
      .replace(/\[Información Adicional\]/g, formData.customText || '[Información Adicional]')
      .replace(/\[Date\]/g, new Date().toLocaleDateString())
      .replace(/\[Fecha\]/g, new Date().toLocaleDateString())

    setGeneratedLetter(template)
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedLetter)
  }

  const downloadLetter = () => {
    const element = document.createElement('a')
    const file = new Blob([generatedLetter], { type: 'text/plain' })
    element.href = URL.createObjectURL(file)
    element.download = `${selectedTemplate}_letter.txt`
    document.body.appendChild(element)
    element.click()
    document.body.removeChild(element)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <FileText className="w-5 h-5" />
            <span>{t.selectTemplate}</span>
          </CardTitle>
          <CardDescription>
            Choose a letter template and fill in your information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
            <SelectTrigger>
              <SelectValue placeholder={t.selectTemplate} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dispute">{t.disputeLetter}</SelectItem>
              <SelectItem value="validation">{t.validationLetter}</SelectItem>
              <SelectItem value="goodwill">{t.goodwillLetter}</SelectItem>
              <SelectItem value="inquiry">{t.inquiryRemoval}</SelectItem>
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      {selectedTemplate && (
        <Card>
          <CardHeader>
            <CardTitle>{t.personalInfo}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">{t.name}</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="address">{t.address}</Label>
                <Input
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="city">{t.city}</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({...formData, city: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="state">{t.state}</Label>
                <Input
                  id="state"
                  value={formData.state}
                  onChange={(e) => setFormData({...formData, state: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="zip">{t.zip}</Label>
                <Input
                  id="zip"
                  value={formData.zip}
                  onChange={(e) => setFormData({...formData, zip: e.target.value})}
                />
              </div>
            </div>

            <div className="space-y-4 pt-4 border-t">
              <h4 className="font-medium">{t.accountDetails}</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="creditorName">{t.creditorName}</Label>
                  <Input
                    id="creditorName"
                    value={formData.creditorName}
                    onChange={(e) => setFormData({...formData, creditorName: e.target.value})}
                  />
                </div>
                <div>
                  <Label htmlFor="accountNumber">{t.accountNumber}</Label>
                  <Input
                    id="accountNumber"
                    value={formData.accountNumber}
                    onChange={(e) => setFormData({...formData, accountNumber: e.target.value})}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="disputeReason">{t.disputeReason}</Label>
                <Input
                  id="disputeReason"
                  value={formData.disputeReason}
                  onChange={(e) => setFormData({...formData, disputeReason: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="customText">{t.customText}</Label>
                <Textarea
                  id="customText"
                  value={formData.customText}
                  onChange={(e) => setFormData({...formData, customText: e.target.value})}
                  rows={3}
                />
              </div>
            </div>

            <Button onClick={generateLetter} className="w-full">
              {t.generateLetter}
            </Button>
          </CardContent>
        </Card>
      )}

      {generatedLetter && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span>{t.letterGenerated}</span>
            </CardTitle>
            <CardDescription className="flex items-center space-x-2 text-amber-600">
              <AlertCircle className="w-4 h-4" />
              <span>{t.disclaimer}</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Textarea
                value={generatedLetter}
                onChange={(e) => setGeneratedLetter(e.target.value)}
                rows={20}
                className="font-mono text-sm"
              />
              <div className="flex space-x-2">
                <Button onClick={downloadLetter} className="flex items-center space-x-2">
                  <Download className="w-4 h-4" />
                  <span>{t.downloadLetter}</span>
                </Button>
                <Button onClick={copyToClipboard} variant="outline" className="flex items-center space-x-2">
                  <Copy className="w-4 h-4" />
                  <span>{t.copyLetter}</span>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

export default LetterGenerator

